#ifndef COMMONVALS
#define COMMONVALS
#include "stb_image.h"

const int MAX_POINT_LIGHTS = 7;
const int MAX_SPOT_LIGHTS = 8;
#endif